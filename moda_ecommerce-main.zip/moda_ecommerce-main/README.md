# Checkpoint I - Micro moda_ecommerce

## Integrantes
Isabella de Souza Campos RM89244

Isabelle Raslosnek Ziteli Panico RM87608
